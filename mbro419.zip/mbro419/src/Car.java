/**
 * Represents a Car object with make, year, and price attributes and implements the Comparable interface for comparing Car objects
 *
 * CSC 1351 Programming Project Part 1
 * Section 2
 *
 * @author Madelaine Brown
 * @since 03/17/2024
 */
public class Car implements Comparable<Car>{

    private String make; //The make of the car
    private int year;    //The year of the car
    private int price;   //The price of the car
    
    /**
     * Constructs a Car object with the given make, year, and price.
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public Car(String Make, int Year, int Price) {
        make = Make;
        year = Year;
        price = Price;
    }
    
    /**
     * Gets the make of the car.
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public String getMake() {
        return this.make;
    }
    
    /**
     * Gets the price of the car
     * 
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public int getPrice() {
        return this.price;
    }
    
    /**
     * Gets the year of the car.
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public int getYear() {
        return this.year;
    }
    
    /**
     * Compares this Car object with another Car object based on their make and year.
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public int compareTo(Car other) {//Compares two cars based on make and then year
        int Comparison = this.make.compareTo(other.make);
        if (make == other.make) {
            return Integer.compare(year, other.year);
        } else {
            return Comparison;
        }	
    }
    
    /**
     * Represents the car object as a string.
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public String toString() {//Contents of the car in a string
        return "Make: " + make + ", Year: " + year + ", Price: " + price + ";";
    }
}
