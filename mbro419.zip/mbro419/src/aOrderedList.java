/**
 * Represents an ordered list that stores elements of different types by using type T.
 *
 * CSC 1351 Programming Project Part 1
 * Section 2
 *
 * @author Madelaine Brown
 * @since 03/17/2024
 */
public class aOrderedList<T extends Comparable<T>> {
    private int listSize;       // The maximum size of the list
    private int numObjects;     // The number of objects currently in the list
    private T[] oList;          // The array to store the elements of the list
    private int curr;           // The index of the current element accessed via iterator methods

    /**
     * Constructs an empty ordered list with an initial capacity of 20
     * 
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public aOrderedList() {
        listSize = 20;          // initial size
        numObjects = 0;
        oList = (T[]) new Comparable[listSize]; // Creating array of type T
        curr = -1;              // initialize and set current index to -1
    }
    /**
     * Returns a string representation of the ordered list
     * 
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < numObjects; i++) {
            sb.append(oList[i].toString());
            if (i < numObjects - 1) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    /**
     * Adds a new object to the ordered list while maintaining its ascending order.
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public void add(T newObject) {
        if (numObjects == listSize) {
            increaseListSize();
        }

        int i = numObjects - 1;
        while (i >= 0 && newObject.compareTo(oList[i]) < 0) {
            oList[i + 1] = oList[i];
            i--;
        }
        oList[i + 1] = newObject;
        numObjects++;
    }

    /**
     * Retrieves the object at the specified index in the ordered list
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public T get(int index) {
        if (index < 0 || index >= numObjects) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        return oList[index];
    }
    /**
     * Checks if the ordered list is empty
     * 
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     *
     */
    public boolean isEmpty() {
        return numObjects == 0;
    }

    /**
     * Resets the current index to -1, indicating the start of the list
     * 
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public void reset() {
        curr = -1; // resets current index to -1
    }

    /**
     * Moves to the next element in the list and returns it
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public T next() {
        curr++; // increments current index
        return oList[curr];
    }

    /**
     * Checks if there are more elements in the list to iterate through
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public boolean hasNext() {
        return curr < numObjects - 1; // check if there are more elements to iterate through
    }

    /**
     * Returns the number of objects currently in the ordered list
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public int size() {
        return numObjects;
    }

    /**
     * Removes the specified Car object from the ordered list
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public void remove(Car car) {
        int index = -1;
        for (int i = 0; i < numObjects; i++) {
            if (oList[i].equals(car)) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            for (int i = index; i < numObjects - 1; i++) {
                oList[i] = oList[i + 1];
            }
            numObjects--;
        }
    }

    /**
     * The size of the array that stores the elements is increased by 20
     * 
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    private void increaseListSize() {
        listSize += 20; // increase size by increments of 20
        T[] newList = (T[]) new Comparable[listSize]; // Creates a new array of type T
        System.arraycopy(oList, 0, newList, 0, numObjects);
        oList = newList;
    }
}
